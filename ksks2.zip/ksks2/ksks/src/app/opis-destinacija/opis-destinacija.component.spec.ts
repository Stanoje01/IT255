import { ComponentFixture, TestBed } from '@angular/core/testing';

import { OpisDestinacijaComponent } from './opis-destinacija.component';

describe('OpisDestinacijaComponent', () => {
  let component: OpisDestinacijaComponent;
  let fixture: ComponentFixture<OpisDestinacijaComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ OpisDestinacijaComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(OpisDestinacijaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
