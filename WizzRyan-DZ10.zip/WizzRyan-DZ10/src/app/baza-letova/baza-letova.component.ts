import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { letovi } from '../modeli/letovi';
import { ApiService } from '../shared/api.service';

@Component({
  selector: 'app-baza-letova',
  templateUrl: './baza-letova.component.html',
  styleUrls: ['./baza-letova.component.css']
})
export class BazaLetovaComponent implements OnInit {

  formValue!: FormGroup;

  letModel: letovi = new letovi();
  letData!: any;
  showAdd!: boolean;
  showUpdate!: boolean;


  constructor(private formbuilder : FormBuilder, private api : ApiService) { }

  ngOnInit(): void {
    this.formValue = this.formbuilder.group({
      id: [''],
      ime: [''], 
      prezime: [''], 
      klasa: [''],
      destinacija: ['']
    })
    this.getAllLet();
  }

  klikDodajLet(){
    this.formValue.reset();
    this.showAdd = true;
    this.showUpdate = false;
  }

  postLetDetalji(){
    this.letModel.ime = this.formValue.value.ime
    this.letModel.prezime = this.formValue.value.prezime
    this.letModel.klasa = this.formValue.value.klasa
    this.letModel.destinacija = this.formValue.value.destinacija

    this.api.postLet(this.letModel).subscribe(res=>{
      console.log(res);
      alert("Uspesno ste dodali let")
      let ref = document.getElementById('cancel')
      ref?.click();
      this.formValue.reset();
      this.getAllLet();
    }, 
    err=>{
      alert("Doslo je do greske!!!!!")
    })
  }

  getAllLet(){
    this.api.getLet().subscribe(res=>{
      this.letData = res;
    })
  }

  obrisiLet(row: any){
    this.api.deleteLet(row.id).subscribe(res=>{
      alert("Uspesno ste obrisali let!")
      this.getAllLet();
    })
  }
  onEdit(row: any){
    this.showAdd = false;
    this.showUpdate = true;
    this.letModel.id = row.id;
    this.formValue.controls['ime'].setValue(row.ime);
    this.formValue.controls['prezime'].setValue(row.prezime);
    this.formValue.controls['klasa'].setValue(row.klasa);
    this.formValue.controls['destinacija'].setValue(row.destinacija);
  }

  updateLetDetails(){
    this.letModel.ime = this.formValue.value.ime;
    this.letModel.prezime = this.formValue.value.prezime;
    this.letModel.klasa = this.formValue.value.klasa;
    this.letModel.destinacija = this.formValue.value.destinacija;

    this.api.updateLet(this.letModel, this.letModel.id)
    .subscribe(res=>{
      alert("Izmena je uspesno izvrsena!");
      let ref = document.getElementById('cancel')
      ref?.click();
      this.formValue.reset();
      this.getAllLet();
    })

  }
}
