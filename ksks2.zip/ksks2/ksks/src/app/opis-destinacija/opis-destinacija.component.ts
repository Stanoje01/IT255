import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { DestinacijeComponent } from '../destinacija/destinacija.component';
import { ProsledjivanjeService } from '../prosledjivanje.service';

@Component({
  selector: 'app-opis-destinacija',
  templateUrl: './opis-destinacija.component.html',
  styleUrls: ['./opis-destinacija.component.css']  
})
export class OpisDestinacijaComponent implements OnInit {
  

  data:any;

  constructor(private prosledjivanjeServis: ProsledjivanjeService){}


  ngOnInit(){ 
    this.data = this.prosledjivanjeServis.getData();
  
    
  } 
}
