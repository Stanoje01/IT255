import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PrikazDestinacijaComponent } from './prikaz-destinacija.component';

describe('PrikazDestinacijaComponent', () => {
  let component: PrikazDestinacijaComponent;
  let fixture: ComponentFixture<PrikazDestinacijaComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PrikazDestinacijaComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PrikazDestinacijaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
