import { Component, EventEmitter, Inject, Input, OnInit, Output } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { OpisDestinacijaComponent } from '../opis-destinacija/opis-destinacija.component';
import { ProsledjivanjeService } from '../prosledjivanje.service';

@Component({
  selector: 'app-destinacija',
  templateUrl: './destinacija.component.html',
  styleUrls: ['./destinacija.component.css']
})
export class DestinacijeComponent implements OnInit {

  @Input() destinacijaSlika: string = '';
  @Input() destinacijaNaziv: string = '';
  @Input() destinacijaDatum: string = '';
  @Input() destinacijaDatum2: string = '';
  @Input() destinacijaOpis: string = '';
  @Input() destinacijaCena: number = 0;
  
  constructor(private prosledjivanjeServis: ProsledjivanjeService ) { 
    
  }

  transferData(){
    this.prosledjivanjeServis.setData({
      naziv: this.destinacijaNaziv, 
      cena: this.destinacijaCena,
      datum: this.destinacijaDatum,
      povratakDatum: this.destinacijaDatum2,
      opis: this.destinacijaOpis,
      slika: this.destinacijaSlika, 
      
    });
  }


  ngOnInit(): void {
  }

}
