import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { BazaService } from '../baza.service';
import { DestinacijeComponent } from '../destinacija/destinacija.component';
import { putnik } from '../modeli/putnik';
import { ProsledjivanjeService } from '../prosledjivanje.service';

@Component({
  selector: 'app-rezervacija',
  templateUrl: './rezervacija.component.html',
  styleUrls: ['./rezervacija.component.css']
})
export class RezervacijaComponent implements OnInit {

  data: any;

  formValue!: FormGroup;
  destinacijaModel!: DestinacijeComponent
  putnikModel: putnik = new putnik();
  putnikData!: any;
  showAdd!: boolean;
  showUpdate!: boolean;

  constructor(private prosledjivanjeServis: ProsledjivanjeService, private formBuilder: FormBuilder, private baza: BazaService) { }


  ngOnInit() {
    this.data = this.prosledjivanjeServis.getData();
    this.formValue = this.formBuilder.group({
      nazivDestinacija: [''],
      datumPolaska: [''],
      datumDolaska: [''],
      cena: [''],
      id: [''],
      ime: [''],
      prezime: [''],
      email: [''],
      telefon: ['']
    })

    this.getAllRez();
  }

  klikDodajRez() {
    this.formValue.reset();
    this.showAdd = true;
    this.showUpdate = false;
  }

  postRezervacija() {

    this.putnikModel.ime = this.formValue.value.ime
    this.putnikModel.prezime = this.formValue.value.prezime
    this.putnikModel.email = this.formValue.value.email
    this.putnikModel.telefon = this.formValue.value.telefon

    this.baza.postRez(this.putnikModel).subscribe(res => {
      console.log(res);
      alert("Uspesno ste dodali let")
      let ref = document.getElementById('cancel')
      ref?.click();
      this.formValue.reset();
      this.getAllRez();
    },
      err => {
        alert("Doslo je do greske")
      })
  }

  getAllRez() {
    this.baza.getRez().subscribe(res => {
      this.putnikData = res;
    })
  }

  // postRezervacija2() {
  //   this.destinacijaModel.destinacijaNaziv = this.formValue.value.nazivDestinacija
  //   this.destinacijaModel.destinacijaDatum = this.formValue.value.datumPolaska
  //   this.destinacijaModel.destinacijaDatum2 = this.formValue.value.datumDolaska
  //   this.destinacijaModel.destinacijaCena = this.formValue.value.cena

  //   this.baza.postRez(this.destinacijaModel).subscribe(res => {
  //     console.log(res);
  //     alert("Uspesno ste dodali let")
  //     let ref = document.getElementById('cancel')
  //     ref?.click();
  //     this.formValue.reset();
  //     this.getAllRez();
  //   },
  //     err => {
  //       alert("Doslo je do greske")
  //     })

  // }
}
