export class KlaseLeta {
    imeKlase:string
    cenaKlase: number
}