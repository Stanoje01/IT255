import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { KontaktComponent } from './kontakt/kontakt.component';
import { LoginKomponentaComponent } from './login-komponenta/login-komponenta.component';
import { ONamaComponent } from './o-nama/o-nama.component';
import { OpisDestinacijaComponent } from './opis-destinacija/opis-destinacija.component';
import { PocetnaStranaComponent } from './pocetna-strana/pocetna-strana.component';
import { PrikazDestinacijaComponent } from './prikaz-destinacija/prikaz-destinacija.component';
import { RegisterComponent } from './register/register.component';
import { RezervacijaComponent } from './rezervacija/rezervacija.component';

const routes: Routes = [
  { path:'login', component:LoginKomponentaComponent},
  { path:'register', component:RegisterComponent},
  { path:'', component:PocetnaStranaComponent},
  { path:'oNama', component:ONamaComponent},
  { path:'kontakt', component:KontaktComponent},
  { path:'destinacije', component:PrikazDestinacijaComponent},
  { path:'opisDestinacija', component:OpisDestinacijaComponent},
  { path:'rezervacija', component:RezervacijaComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
