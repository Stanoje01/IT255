export class Firma {
    public imeFirme: string;
    public godinaNastanka: number;
    public vlasnik: string;

    
}