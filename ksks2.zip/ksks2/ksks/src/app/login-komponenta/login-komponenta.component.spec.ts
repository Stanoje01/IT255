import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LoginKomponentaComponent } from './login-komponenta.component';

describe('LoginKomponentaComponent', () => {
  let component: LoginKomponentaComponent;
  let fixture: ComponentFixture<LoginKomponentaComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ LoginKomponentaComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(LoginKomponentaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
