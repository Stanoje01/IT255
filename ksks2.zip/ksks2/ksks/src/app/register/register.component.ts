import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { ApiService } from '../api/api.service';
import { Korisnik } from '../modeli/korisnik';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  formValue!: FormGroup;
  korisnikModel: Korisnik = new Korisnik();
  korisnikData: any;
  showAdd!:boolean;


  constructor(private formbuilder : FormBuilder, private api : ApiService) { }

  ngOnInit(): void {
    this.formValue = this.formbuilder.group({
      id: [''],
      username: [''], 
      password: [''], 
      email: [''],
    })
  }

  postKorisnikDetalji(){
  
    this.korisnikModel.rola = 'user'
    this.korisnikModel.username = this.formValue.value.username
    this.korisnikModel.password = this.formValue.value.password
    this.korisnikModel.email = this.formValue.value.email
    

    this.api.postKorisnik(this.korisnikModel).subscribe(res=>{
      console.log(res);
      alert("Uspesno ste se registrovali")
      this.formValue.reset();
    }, 
    err=>{
      alert("Doslo je do greske!!!!!")
    })
  }

}
