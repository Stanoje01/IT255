import { Injectable } from '@angular/core';
import { CanActivate } from '@angular/router';
import { Router } from 'express';

@Injectable({
  providedIn: 'root'
})
export class RouteGuardService implements CanActivate {

  constructor(private router: Router) { }

  canActivate(): boolean{
    const rola = localStorage.getItem('rola');
    if(rola !== 'admin' && rola !== 'user'){
      (<any>this.router).navigate(['login']);
      return false;
    }
    if (rola === 'admin') {
      (<any>this.router).navigate(['admin']);
    } else {
      (<any>this.router).navigate(['user']);
    }
    return true;
  } 
 }

