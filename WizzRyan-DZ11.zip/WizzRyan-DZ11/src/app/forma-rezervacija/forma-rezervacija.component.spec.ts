import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FormaRezervacijaComponent } from './forma-rezervacija.component';

describe('FormaRezervacijaComponent', () => {
  let component: FormaRezervacijaComponent;
  let fixture: ComponentFixture<FormaRezervacijaComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ FormaRezervacijaComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(FormaRezervacijaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
