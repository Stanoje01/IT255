import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-putnik',
  templateUrl: './putnik.component.html',
  styleUrls: ['./putnik.component.css']
})
export class PutnikComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
