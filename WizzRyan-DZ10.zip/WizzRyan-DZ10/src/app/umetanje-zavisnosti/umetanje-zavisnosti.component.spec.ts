import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UmetanjeZavisnostiComponent } from './umetanje-zavisnosti.component';

describe('UmetanjeZavisnostiComponent', () => {
  let component: UmetanjeZavisnostiComponent;
  let fixture: ComponentFixture<UmetanjeZavisnostiComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UmetanjeZavisnostiComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(UmetanjeZavisnostiComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
