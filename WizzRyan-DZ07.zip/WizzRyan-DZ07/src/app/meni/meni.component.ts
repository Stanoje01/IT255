import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-meni',
  templateUrl: './meni.component.html',
  styleUrls: ['./meni.component.css']
})
export class MeniComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }


  
}
