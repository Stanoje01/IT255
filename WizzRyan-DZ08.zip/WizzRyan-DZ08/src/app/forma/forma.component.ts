import { Component, OnInit } from '@angular/core';
import { FormControl, Validators } from '@angular/forms';


@Component({
  selector: 'app-forma',
  templateUrl: './forma.component.html',
  styleUrls: ['./forma.component.css']
})
export class FormaComponent{

  sifra: any = new FormControl('', [
    Validators.minLength(6)
  ]);
  destinacija: any = new FormControl('', [
    Validators.minLength(3)
  ]);
  kompanija: any = new FormControl('', [
    Validators.minLength(3)
  ]);

  tabela: any[] = [];

  

  dodaj(){
    this.tabela.push({sifra: this.sifra, destinacija: this.destinacija, kompanija: this.kompanija});
    
  }

}
