import { Component } from '@angular/core';

@Component({
  selector: 'app-prikaz-destinacija',
  templateUrl: './prikaz-destinacija.component.html',
  styleUrls: ['./prikaz-destinacija.component.css']
})
export class PrikazDestinacijaComponent {

  destinacija = [
    {
      slika:'assets/zanzibar.jpg',
      naziv:'Zanzibar',
      datum:'23.05.2023',
      povratakDatum:'02.06.2023',
      opis:"Zanzibar je ostrvska zemlja smeštena u Indijskom okeanu i nalazi se na 35km od afričko - tanuanijske obale" + 
      "Sastoji se od nekoliko ostrva od koji su najveća Pemba i Unguja. Glavni grad se nalazi na Unguji, koja se deli na 3 oblasti: sever,"
      +" jug i grad Zanzibar.U samom gradu nalazi se Stone town koji je građen u osnovi svahili arhitekture ali i pod persijskim, indijskim i evropskim uticajem. Zbog svoje lepote i kulturno istorijske vrednosti od 2000."
      +" godine je pod zaštitom Uneska.Kao autonomna pokrajina Tanzanije, dobro je povezan sa glavnim gradom Dar Es Salamom koji je udaljen 2h vožnje trajektom. Klima je tropska, a prosečna godišnja temperatura 26 stepeni."
      +" Zvanični jezici su svahili i engleski, a valuta tanzanijski šiling.Kako je Zanzibar država koja je poslednjih decenija počela da se razvija, smeštajni kapaciteti su novijih datuma a priroda još uvek očuvana u svojoj lepoti."
      + "Čisto i toplo more, prelepe peščane plaže i mnogo zelenila čini Zanzibar rajskom destinacijom za odmor.",
      cena:890
    },{
      slika:'assets/tasos.jpg',
      naziv:'Tasos',
      datum:'20.07.2023',
      povratakDatum:'30.07.2023',
      opis:"Zanzibar je ostrvska zemlja smeštena u Indijskom okeanu i nalazi se na 35km od afričko - tanuanijske obale" + 
      "Sastoji se od nekoliko ostrva od koji su najveća Pemba i Unguja. Glavni grad se nalazi na Unguji, koja se deli na 3 oblasti: sever,"
      +" jug i grad Zanzibar.U samom gradu nalazi se Stone town koji je građen u osnovi svahili arhitekture ali i pod persijskim, indijskim i evropskim uticajem. Zbog svoje lepote i kulturno istorijske vrednosti od 2000."
      +" godine je pod zaštitom Uneska.Kao autonomna pokrajina Tanzanije, dobro je povezan sa glavnim gradom Dar Es Salamom koji je udaljen 2h vožnje trajektom. Klima je tropska, a prosečna godišnja temperatura 26 stepeni."
      +" Zvanični jezici su svahili i engleski, a valuta tanzanijski šiling.Kako je Zanzibar država koja je poslednjih decenija počela da se razvija, smeštajni kapaciteti su novijih datuma a priroda još uvek očuvana u svojoj lepoti."
      + "Čisto i toplo more, prelepe peščane plaže i mnogo zelenila čini Zanzibar rajskom destinacijom za odmor.",
      cena:320
    },{
      slika:'assets/ibica.jpg',
      naziv:'Ibica',
      datum:'16.08.2023',
      povratakDatum:'30.08.2023',
      opis:"Zanzibar je ostrvska zemlja smeštena u Indijskom okeanu i nalazi se na 35km od afričko - tanuanijske obale" + 
      "Sastoji se od nekoliko ostrva od koji su najveća Pemba i Unguja. Glavni grad se nalazi na Unguji, koja se deli na 3 oblasti: sever,"
      +" jug i grad Zanzibar.U samom gradu nalazi se Stone town koji je građen u osnovi svahili arhitekture ali i pod persijskim, indijskim i evropskim uticajem. Zbog svoje lepote i kulturno istorijske vrednosti od 2000."
      +" godine je pod zaštitom Uneska.Kao autonomna pokrajina Tanzanije, dobro je povezan sa glavnim gradom Dar Es Salamom koji je udaljen 2h vožnje trajektom. Klima je tropska, a prosečna godišnja temperatura 26 stepeni."
      +" Zvanični jezici su svahili i engleski, a valuta tanzanijski šiling.Kako je Zanzibar država koja je poslednjih decenija počela da se razvija, smeštajni kapaciteti su novijih datuma a priroda još uvek očuvana u svojoj lepoti."
      + "Čisto i toplo more, prelepe peščane plaže i mnogo zelenila čini Zanzibar rajskom destinacijom za odmor.",
      cena:450
    },{
      slika:'assets/florida.jpg',
      naziv:'Florida',
      datum:'16.06.2023',
      povratakDatum:'28.06.2023',
      opis:"Zanzibar je ostrvska zemlja smeštena u Indijskom okeanu i nalazi se na 35km od afričko - tanuanijske obale" + 
      "Sastoji se od nekoliko ostrva od koji su najveća Pemba i Unguja. Glavni grad se nalazi na Unguji, koja se deli na 3 oblasti: sever,"
      +" jug i grad Zanzibar.U samom gradu nalazi se Stone town koji je građen u osnovi svahili arhitekture ali i pod persijskim, indijskim i evropskim uticajem. Zbog svoje lepote i kulturno istorijske vrednosti od 2000."
      +" godine je pod zaštitom Uneska.Kao autonomna pokrajina Tanzanije, dobro je povezan sa glavnim gradom Dar Es Salamom koji je udaljen 2h vožnje trajektom. Klima je tropska, a prosečna godišnja temperatura 26 stepeni."
      +" Zvanični jezici su svahili i engleski, a valuta tanzanijski šiling.Kako je Zanzibar država koja je poslednjih decenija počela da se razvija, smeštajni kapaciteti su novijih datuma a priroda još uvek očuvana u svojoj lepoti."
      + "Čisto i toplo more, prelepe peščane plaže i mnogo zelenila čini Zanzibar rajskom destinacijom za odmor.",
      cena:1600
    },
    {
      slika:'assets/kusadasi.jpg',
      naziv:'Kusadasi',
      datum:'20.07.2023',
      povratakDatum:'02.08.2023',
      opis:"Zanzibar je ostrvska zemlja smeštena u Indijskom okeanu i nalazi se na 35km od afričko - tanuanijske obale" + 
      "Sastoji se od nekoliko ostrva od koji su najveća Pemba i Unguja. Glavni grad se nalazi na Unguji, koja se deli na 3 oblasti: sever,"
      +" jug i grad Zanzibar.U samom gradu nalazi se Stone town koji je građen u osnovi svahili arhitekture ali i pod persijskim, indijskim i evropskim uticajem. Zbog svoje lepote i kulturno istorijske vrednosti od 2000."
      +" godine je pod zaštitom Uneska.Kao autonomna pokrajina Tanzanije, dobro je povezan sa glavnim gradom Dar Es Salamom koji je udaljen 2h vožnje trajektom. Klima je tropska, a prosečna godišnja temperatura 26 stepeni."
      +" Zvanični jezici su svahili i engleski, a valuta tanzanijski šiling.Kako je Zanzibar država koja je poslednjih decenija počela da se razvija, smeštajni kapaciteti su novijih datuma a priroda još uvek očuvana u svojoj lepoti."
      + "Čisto i toplo more, prelepe peščane plaže i mnogo zelenila čini Zanzibar rajskom destinacijom za odmor.",
      cena:320
    },{
      slika:'assets/nica.jpg',
      naziv:'Nica',
      datum:'19.07.2023.',
      povratakDatum:'01.08.2023',
      opis:"Zanzibar je ostrvska zemlja smeštena u Indijskom okeanu i nalazi se na 35km od afričko - tanuanijske obale" + 
      "Sastoji se od nekoliko ostrva od koji su najveća Pemba i Unguja. Glavni grad se nalazi na Unguji, koja se deli na 3 oblasti: sever,"
      +" jug i grad Zanzibar.U samom gradu nalazi se Stone town koji je građen u osnovi svahili arhitekture ali i pod persijskim, indijskim i evropskim uticajem. Zbog svoje lepote i kulturno istorijske vrednosti od 2000."
      +" godine je pod zaštitom Uneska.Kao autonomna pokrajina Tanzanije, dobro je povezan sa glavnim gradom Dar Es Salamom koji je udaljen 2h vožnje trajektom. Klima je tropska, a prosečna godišnja temperatura 26 stepeni."
      +" Zvanični jezici su svahili i engleski, a valuta tanzanijski šiling.Kako je Zanzibar država koja je poslednjih decenija počela da se razvija, smeštajni kapaciteti su novijih datuma a priroda još uvek očuvana u svojoj lepoti."
      + "Čisto i toplo more, prelepe peščane plaže i mnogo zelenila čini Zanzibar rajskom destinacijom za odmor.",
      cena:710
    },{
      slika:'assets/santorini.jpg',
      naziv:'Santorini',
      datum:'08.08.2023',
      povratakDatum:'23.08.2023',
      opis:"Zanzibar je ostrvska zemlja smeštena u Indijskom okeanu i nalazi se na 35km od afričko - tanuanijske obale" + 
      "Sastoji se od nekoliko ostrva od koji su najveća Pemba i Unguja. Glavni grad se nalazi na Unguji, koja se deli na 3 oblasti: sever,"
      +" jug i grad Zanzibar.U samom gradu nalazi se Stone town koji je građen u osnovi svahili arhitekture ali i pod persijskim, indijskim i evropskim uticajem. Zbog svoje lepote i kulturno istorijske vrednosti od 2000."
      +" godine je pod zaštitom Uneska.Kao autonomna pokrajina Tanzanije, dobro je povezan sa glavnim gradom Dar Es Salamom koji je udaljen 2h vožnje trajektom. Klima je tropska, a prosečna godišnja temperatura 26 stepeni."
      +" Zvanični jezici su svahili i engleski, a valuta tanzanijski šiling.Kako je Zanzibar država koja je poslednjih decenija počela da se razvija, smeštajni kapaciteti su novijih datuma a priroda još uvek očuvana u svojoj lepoti."
      + "Čisto i toplo more, prelepe peščane plaže i mnogo zelenila čini Zanzibar rajskom destinacijom za odmor.",
      cena:650
    },
    {
      slika:'assets/pefko.jpg',
      naziv:'Pefkohori',
      datum:'12.07.2023',
      povratakDatum:'27.07.2023',
      opis:"Zanzibar je ostrvska zemlja smeštena u Indijskom okeanu i nalazi se na 35km od afričko - tanuanijske obale" + 
      "Sastoji se od nekoliko ostrva od koji su najveća Pemba i Unguja. Glavni grad se nalazi na Unguji, koja se deli na 3 oblasti: sever,"
      +" jug i grad Zanzibar.U samom gradu nalazi se Stone town koji je građen u osnovi svahili arhitekture ali i pod persijskim, indijskim i evropskim uticajem. Zbog svoje lepote i kulturno istorijske vrednosti od 2000."
      +" godine je pod zaštitom Uneska.Kao autonomna pokrajina Tanzanije, dobro je povezan sa glavnim gradom Dar Es Salamom koji je udaljen 2h vožnje trajektom. Klima je tropska, a prosečna godišnja temperatura 26 stepeni."
      +" Zvanični jezici su svahili i engleski, a valuta tanzanijski šiling.Kako je Zanzibar država koja je poslednjih decenija počela da se razvija, smeštajni kapaciteti su novijih datuma a priroda još uvek očuvana u svojoj lepoti."
      + "Čisto i toplo more, prelepe peščane plaže i mnogo zelenila čini Zanzibar rajskom destinacijom za odmor.",
      cena:250
    }
  ];

  klikDestinacija(destinacija: any){
    console.log(destinacija)
  }
}
