export class Korisnik {
    rola: string = ''
    username: string = ''
    password: string = ''
    email: string = ''
}