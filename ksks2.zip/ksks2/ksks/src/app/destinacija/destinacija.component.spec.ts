import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DestinacijeComponent } from './destinacija.component';

describe('DestinacijeComponent', () => {
  let component: DestinacijeComponent;
  let fixture: ComponentFixture<DestinacijeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DestinacijeComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(DestinacijeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
