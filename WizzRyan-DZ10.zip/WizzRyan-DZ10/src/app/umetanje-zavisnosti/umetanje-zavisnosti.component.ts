import { Component, OnInit } from '@angular/core';
import { FlightServices } from '../services/flightServies';

@Component({
  selector: 'app-umetanje-zavisnosti',
  templateUrl: './umetanje-zavisnosti.component.html',
  styleUrls: ['./umetanje-zavisnosti.component.css']
})
export class UmetanjeZavisnostiComponent{

  constructor(private flightServices : FlightServices) { }

  
  prikazCene(){
    const numberOfFlights = 10;
    const cena = this.flightServices.getPrice(numberOfFlights);
    alert("Broj danasnjih letova je: " + numberOfFlights 
    + " i cena iznosi: " + cena + " evra.")
  }
}
