import { Component, NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { BazaLetovaComponent } from './baza-letova/baza-letova.component';
import { FormaRezervacijaComponent } from './forma-rezervacija/forma-rezervacija.component';
import { FormaComponent } from './forma/forma.component';
import { LetComponent } from './let/let.component';
import { ONamaComponent } from './o-nama/o-nama.component';
import { PonudaComponent } from './ponuda/ponuda.component';


const routes: Routes = [
  { path: 'rezervacija', component:FormaRezervacijaComponent},
  { path: '', component:LetComponent},
  { path: 'dodajLet', component:FormaComponent},
  { path: 'oNama', component:ONamaComponent}, 
  { path: 'popust', component:PonudaComponent},
  { path: 'baza', component:BazaLetovaComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
