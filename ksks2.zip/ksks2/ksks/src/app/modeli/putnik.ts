export class putnik{
    id!:number 
    ime: string = ''
    prezime: string  = ''
    email: string = ''
    telefon: string = ''
}