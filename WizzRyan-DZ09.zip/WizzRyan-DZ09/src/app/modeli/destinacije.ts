export class Destinacije {
 
    nazivDestinacije: string
    cenaDestinacije: number
}