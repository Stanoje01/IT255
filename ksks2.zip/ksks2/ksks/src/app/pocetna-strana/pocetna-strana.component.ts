import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pocetna-strana',
  templateUrl: './pocetna-strana.component.html',
  styleUrls: ['./pocetna-strana.component.css']
})
export class PocetnaStranaComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
