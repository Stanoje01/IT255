import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ponuda',
  templateUrl: './ponuda.component.html',
  styleUrls: ['./ponuda.component.css']
})
export class PonudaComponent implements OnInit {
  ponuda: string;
  

  ngOnInit(): void {
  }

  klikPonuda(){
    alert("Klikom na ovo dugme ostvraili ste popust u iznosu od 20% na sledece odabrano putovanje!!!!")
  }
}
