import { Input } from "@angular/core";


export class destinacija {
    @Input() destinacijaSlika: string = '';
    @Input() destinacijaNaziv: string = '';
    @Input() destinacijaDatum: string = '';
    @Input() destinacijaDatum2: string = '';
    @Input() destinacijaOpis: string = '';
    @Input() destinacijaCena: number = 0;
}
