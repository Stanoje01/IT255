
import { Component, OnInit } from '@angular/core';
import { AuthService } from '../auth.service';

@Component({
  selector: 'app-login-komponenta',
  templateUrl: './login-komponenta.component.html',
  styleUrls: ['./login-komponenta.component.css']
})
export class LoginKomponentaComponent {
  username = '';
  password = '';

  constructor(private authServis: AuthService) { }

  login() {
    this.authServis.login(this.username, this.password);
  }


}
