import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { FormaRezervacijaComponent } from './forma-rezervacija/forma-rezervacija.component';
import { FormaComponent } from './forma/forma.component';
import { LetComponent } from './let/let.component';
import { ONamaComponent } from './o-nama/o-nama.component';
import { PonudaComponent } from './ponuda/ponuda.component';


const routes: Routes = [
  { path: 'rezervacija', component:FormaRezervacijaComponent},
  { path: '', component:LetComponent},
  { path: 'dodajLet', component:FormaComponent},
  { path: 'oNama', component:ONamaComponent}, 
  { path: 'popust', component:PonudaComponent}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
