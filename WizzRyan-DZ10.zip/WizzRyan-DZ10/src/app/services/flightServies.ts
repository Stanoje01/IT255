import { Injectable } from "@angular/core";

@Injectable({
    providedIn:'root'
})

export class FlightServices {
    constructor (){}

    getPrice(numberOfFlights: number): number {
        return numberOfFlights *1000;
    }
}