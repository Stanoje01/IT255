export class Let{
    constructor(public sifraLeta: string, public destinacija: string, public kompanija: string) {}
}