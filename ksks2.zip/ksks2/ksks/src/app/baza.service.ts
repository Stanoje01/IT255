import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { map } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class BazaService {

  constructor(private http : HttpClient) { }

  postRez(data : any) {
    return this.http.post<any>("http://localhost:3000/rezervacija/", data)
    .pipe(map((res:any)=>{
      return res;
    }))
  }

  getRez(){
    return this.http.get<any>("http://localhost:3000/rezervacija/")
    .pipe(map((res:any)=>{
      return res;
    }))
  }
}
