import { HttpClient } from '@angular/common/http';
import { Injectable, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Router } from 'express';

@Injectable({
  providedIn: 'root'
})
export class AuthService implements OnInit {

  private isLoggedIn = false;
  private username!: string;

  public loginForm!: FormGroup;

  constructor(private formBuilder: FormBuilder, private http: HttpClient, private router: Router) { }

  ngOnInit(): void {
    this.loginForm = this.formBuilder.group({
      username: [''],
      email: [''],
      password: [""]
    })
  }

  login(username: string, password: string) {
    this.http.get<any>("http://localhost:3000/korisnik/").subscribe((data) => {
      for (let korisnik of data) {
        if (korisnik.username === username && korisnik.password === password) {
          this.isLoggedIn = true;
          this.username = username;
          return;
        }
      }
      alert("Nesto nije u redu")
    });
    
  }

isAuth(){
  return this.isLoggedIn
}

getUsername(){
  return this.username
}
}
