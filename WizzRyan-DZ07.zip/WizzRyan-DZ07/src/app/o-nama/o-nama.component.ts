import { Component, OnInit } from '@angular/core';
import { Firma } from '../modeli/firma';

@Component({
  selector: 'app-o-nama',
  templateUrl: './o-nama.component.html',
  styleUrls: ['./o-nama.component.css']
})
export class ONamaComponent implements OnInit {

  firma: Firma = new Firma()
  constructor() { 
    
  }

  ngOnInit(): void {
  }

  oNama(){
    this.firma.imeFirme = "Sale travel"
    this.firma.godinaNastanka = 2001
    this.firma.vlasnik = "Sasa Stanojevic"
  }

}
