export class letovi{
    id: number; 
    ime: string;
    prezime:string;
    klasa:string;
    destinacija: string;

}