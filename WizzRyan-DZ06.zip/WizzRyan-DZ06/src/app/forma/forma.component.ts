import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-forma',
  templateUrl: './forma.component.html',
  styleUrls: ['./forma.component.css']
})
export class FormaComponent{

  dodaj(sifraLeta:HTMLInputElement, destinacija:HTMLInputElement, kompanija: HTMLInputElement) : boolean{ 
    console.log("Sifra leta glasi: ${sifraLeta.value}, idemo na destinaciju: ${destinacija.value} kompanijom ${kompanija.value}")
    return false;
  }

}
