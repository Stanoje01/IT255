import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LetComponent } from './let/let.component';
import { HeaderComponent } from './header/header.component';
import { FormaComponent } from './forma/forma.component';
import { ONamaComponent } from './o-nama/o-nama.component';
import { MeniComponent } from './meni/meni.component';
import { PonudaComponent } from './ponuda/ponuda.component';
import { FormControl, FormGroup, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { FormaRezervacijaComponent } from './forma-rezervacija/forma-rezervacija.component';
import { PutnikComponent } from './putnik/putnik.component';
import { UmetanjeZavisnostiComponent } from './umetanje-zavisnosti/umetanje-zavisnosti.component';

@NgModule({

  
  declarations: [
    AppComponent,
    LetComponent,
    HeaderComponent,
    FormaComponent,
    ONamaComponent,
    MeniComponent,
    PonudaComponent,
    FormaRezervacijaComponent,
    PutnikComponent,
    UmetanjeZavisnostiComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule, 
    FormsModule,
    ReactiveFormsModule,

  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
