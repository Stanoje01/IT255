export class destinacija {
    destinacijaSlika: string = '';
    destinacijaNaziv: string = '';
    destinacijaDatum: string = '';
    destinacijaDatum2: string = '';
    destinacijaOpis: string = '';
    destinacijaCena: number = 0;
}
