import { Component, OnInit } from '@angular/core';
import { Destinacije } from '../modeli/destinacije';
import { KlaseLeta } from '../modeli/klase';

@Component({
  selector: 'app-forma-rezervacija',
  templateUrl: './forma-rezervacija.component.html',
  styleUrls: ['./forma-rezervacija.component.css']
})
export class FormaRezervacijaComponent {

  ime: string
  prezime: string  
  destinacije: Destinacije[] = [
    { nazivDestinacije: 'Dubai', cenaDestinacije: 15000 },
    { nazivDestinacije: 'Pariz', cenaDestinacije: 16000 },
    { nazivDestinacije: 'London', cenaDestinacije: 13000 },
    { nazivDestinacije: 'Rim', cenaDestinacije: 12500 },
  ];
  izabranaDestinacije: Destinacije;

  klase: KlaseLeta[] = [
    { imeKlase: 'Ekonomska klasa', cenaKlase: 8000 },
    { imeKlase: 'Biznis klasa', cenaKlase: 12000 }
  ];
  izabranaKlasa: KlaseLeta;


  showAlert() {
    const ukupnaCena = this.izabranaDestinacije.cenaDestinacije + this.izabranaKlasa.cenaKlase
    alert("Rezervacija glasi na ime: " + this.ime + " " + this.prezime + ". Vasa destinacija je "+ this.izabranaDestinacije.nazivDestinacije + 
    " i letite " + this.izabranaKlasa.imeKlase + ". Cena vase rezervacije iznosi: " + ukupnaCena + " dinara. Srecan put!!!!")
  }
}
