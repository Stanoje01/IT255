import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-let',
  templateUrl: './let.component.html',
  styleUrls: ['./let.component.css']
})
export class LetComponent implements OnInit {

  
  public sifraLeta: string = "SRB001";
  public destinacija: string = "Katar";
  public kompanija: string = "AirSerbia";
  
  public sifraLeta1: string = "SRB002";
  public destinacija1: string = "Pariz";
  public kompanija1: string = "AirSerbia";
  
  ngOnInit(): void {
  }

}
